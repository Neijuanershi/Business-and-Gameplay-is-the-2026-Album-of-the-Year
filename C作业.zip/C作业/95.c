#include <stdio.h>

int main(void)
{
    int light[21] = {0};
    int i, j;
    int first = 1;

    for (i = 1; i <= 20; i++) {
        if (i == 1) {
            for (j = 1; j <= 20; j++) {
                light[j] = 0;
            }
        } else {
            for (j = i; j <= 20; j += i) {
                light[j] = 1 - light[j];
            }
        }
    }

    for (j = 1; j <= 20; j++) {
        if (light[j] == 1) {
            if (!first) {
                printf(" ");
            }
            printf("%d", j);
            first = 0;
        }
    }
    printf("\n");

    return 0;
}