#include <stdio.h>

int main(void) {
    int n, i, is_prime;
    int count = 0;

    for (n = 101; n <= 200; n++) {
        is_prime = 1;
        for (i = 2; i * i <= n; i++) {
            if (n % i == 0) {
                is_prime = 0;
                break;
            }
        }
        if (is_prime) {
            count++;
            if (count % 10 != 1) {
                printf(" ");
            }
            printf("%d", n);
            if (count % 10 == 0) {
                printf("\n");
            }
        }
    }

    for (n = 301; n <= 400; n++) {
        is_prime = 1;
        for (i = 2; i * i <= n; i++) {
            if (n % i == 0) {
                is_prime = 0;
                break;
            }
        }
        if (is_prime) {
            count++;
            if (count % 10 != 1) {
                printf(" ");
            }
            printf("%d", n);
            if (count % 10 == 0) {
                printf("\n");
            }
        }
    }

    if (count % 10 != 0) {
        printf("\n");
    }

    return 0;
}