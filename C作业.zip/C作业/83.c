#include <stdio.h>

int IsPrime(int n)
{
    int i;
    if (n <= 1) {
        return 0;
    }
    for (i = 2; i * i <= n; i++) {
        if (n % i == 0) {
            return 0;
        }
    }
    return 1;
}

int main(void)
{
    int n, i;
    scanf("%d", &n);
    for (i = 2; i <= n / 2; i++) {
        if (IsPrime(i) && IsPrime(n - i)) {
            printf("%d=%d+%d\n", n, i, n - i);
        }
    }
    return 0;
}