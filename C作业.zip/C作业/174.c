#include <stdio.h>

char s[1000005];
char st[1000005];

int main(void)
{
    int top = 0;
    int i = 0;
    int ok = 1;
    if (fgets(s, sizeof(s), stdin) == NULL) {
        printf("Match\n");
        return 0;
    }
    while (s[i] != '\0') {
        char c = s[i];
        if (c == '{' || c == '[' || c == '(') {
            st[top++] = c;
        } else if (c == '}' || c == ']' || c == ')') {
            if (top == 0) {
                ok = 0;
                break;
            }
            char t = st[--top];
            if ((c == '}' && t != '{') || (c == ']' && t != '[') || (c == ')' && t != '(')) {
                ok = 0;
                break;
            }
        }
        i++;
    }
    if (top != 0) ok = 0;
    if (ok) {
        printf("Match\n");
    } else {
        printf("Mismatch\n");
    }
    return 0;
}