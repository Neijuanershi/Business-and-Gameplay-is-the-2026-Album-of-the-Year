#include <stdio.h>

int main(void) {
    int total, h, m, s;
    scanf("%d", &total);
    h = total / 3600;
    m = (total % 3600) / 60;
    s = total % 60;
    printf("%d:%02d:%02d\n", h, m, s);
    return 0;
}