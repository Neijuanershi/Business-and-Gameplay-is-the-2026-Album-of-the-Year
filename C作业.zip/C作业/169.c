#include <stdio.h>

char s1[1000005];
char s2[1000005];
char out[2000005];

int main(void)
{
    int len1 = 0, len2 = 0;
    int n = 0;
    int i;
    int p = 0;
    if (fgets(s1, sizeof(s1), stdin) == NULL) {
        printf("\n");
        return 0;
    }
    if (fgets(s2, sizeof(s2), stdin) == NULL) {
        printf("\n");
        return 0;
    }
    while (s1[len1] != '\0' && s1[len1] != '\n' && s1[len1] != '\r') len1++;
    while (s2[len2] != '\0' && s2[len2] != '\n' && s2[len2] != '\r') len2++;
    if (scanf("%d", &n) != 1) n = 0;
    if (n < 0) n = 0;
    if (n > len1) n = len1;
    for (i = 0; i < n; i++) out[p++] = s1[i];
    for (i = 0; i < len2; i++) out[p++] = s2[i];
    for (i = n; i < len1; i++) out[p++] = s1[i];
    out[p] = '\0';
    printf("%s\n", out);
    return 0;
}