#include <stdio.h>

int main(void)
{
    int a[8];
    int i, j, min_idx, temp;

    for (i = 0; i < 8; i++) {
        scanf("%d", &a[i]);
    }

    for (i = 0; i < 7; i++) {
        min_idx = i;
        for (j = i + 1; j < 8; j++) {
            if (a[j] < a[min_idx]) {
                min_idx = j;
            }
        }
        if (min_idx != i) {
            temp = a[i];
            a[i] = a[min_idx];
            a[min_idx] = temp;
        }
    }

    for (i = 0; i < 8; i++) {
        if (i > 0) {
            printf(" ");
        }
        printf("%d", a[i]);
    }
    printf("\n");

    return 0;
}