#include <stdio.h>

char s[1000005];

int main(void)
{
    int i = 0;
    char c;
    if (fgets(s, sizeof(s), stdin) == NULL) {
        printf("\n");
        return 0;
    }
    while (s[i] != '\0' && s[i] != '\n' && s[i] != '\r') {
        c = s[i];
        if (c >= '0' && c <= '9') {
            putchar('$');
        }
        putchar(c);
        i++;
    }
    putchar('\n');
    return 0;
}