#include <stdio.h>

int main(void) {
    int y1, m1, d1, y2, m2, d2;
    scanf("%d-%d-%d", &y1, &m1, &d1);
    scanf("%d-%d-%d", &y2, &m2, &d2);
    if (y1 < y2) {
        printf("Yes\n");
    } else if (y1 > y2) {
        printf("No\n");
    } else {
        if (m1 < m2) {
            printf("Yes\n");
        } else if (m1 > m2) {
            printf("No\n");
        } else {
            if (d1 < d2) {
                printf("Yes\n");
            } else {
                printf("No\n");
            }
        }
    }
    return 0;
}