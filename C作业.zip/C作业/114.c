#include <stdio.h>

int main(void)
{
    int a[] = {11, 19, 9, 12, 5, 20, 1, 18, 4, 16, 6, 10, 15, 2, 17, 3, 14, 7, 13, 8};
    int max_sum = -1;
    int max_idx = 0;
    int i, sum;

    for (i = 0; i < 20; i++) {
        sum = a[i] + a[(i + 1) % 20] + a[(i + 2) % 20] + a[(i + 3) % 20];
        if (sum > max_sum) {
            max_sum = sum;
            max_idx = i;
        }
    }

    printf("%d\n", max_idx + 1);
    for (i = 0; i < 4; i++) {
        if (i > 0) {
            printf(" ");
        }
        printf("%d", a[(max_idx + i) % 20]);
    }
    printf("\n");

    return 0;
}