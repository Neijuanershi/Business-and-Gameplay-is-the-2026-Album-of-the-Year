#include <stdio.h>

char s[1000005];
char best[1000005];

int main(void)
{
    int i = 0;
    int start = 0;
    int maxLen = 0;
    int curLen = 0;
    int curStart = 0;
    int j;
    if (fgets(s, sizeof(s), stdin) == NULL) {
        printf("\n");
        return 0;
    }
    while (s[i] != '\0' && s[i] != '\n' && s[i] != '\r') {
        if (s[i] == ' ' || s[i] == '\t') {
            if (curLen > maxLen) {
                maxLen = curLen;
                start = curStart;
            }
            curLen = 0;
            curStart = i + 1;
        } else {
            if (curLen == 0) curStart = i;
            curLen++;
        }
        i++;
    }
    if (curLen > maxLen) {
        maxLen = curLen;
        start = curStart;
    }
    for (j = 0; j < maxLen; j++) best[j] = s[start + j];
    best[maxLen] = '\0';
    printf("%s\n", best);
    return 0;
}