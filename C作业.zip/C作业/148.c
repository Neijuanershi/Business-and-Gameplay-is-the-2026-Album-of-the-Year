#include <stdio.h>

int main(void)
{
    char ch;
    int count[26] = {0};
    int i;

    while ((ch = getchar()) != '\n' && ch != EOF) {
        if (ch >= 'a' && ch <= 'z') {
            ch = ch - 'a' + 'A';
        }
        if (ch >= 'A' && ch <= 'Z') {
            count[ch - 'A']++;
        }
    }

    for (i = 0; i < 26; i++) {
        if (count[i] > 0) {
            printf("%c %d\n", 'A' + i, count[i]);
        }
    }

    return 0;
}