#include <stdio.h>

int main(void) {
    double a, b, result = 0.0;
    char op;
    scanf("%lf %c %lf", &a, &op, &b);
    if (op == '+') {
        result = a + b;
    } else if (op == '-') {
        result = a - b;
    } else if (op == '*') {
        result = a * b;
    } else if (op == '/') {
        if (b == 0) {
            printf("Error\n");
            return 0;
        }
        result = a / b;
    } else {
        printf("Error\n");
        return 0;
    }
    printf("%.2f\n", result);
    return 0;
}