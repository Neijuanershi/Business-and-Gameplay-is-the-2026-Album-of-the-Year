#include <stdio.h>

int IsLeap(int y)
{
    if ((y % 4 == 0 && y % 100 != 0) || (y % 400 == 0)) {
        return 1;
    }
    return 0;
}

int main(void)
{
    int y, m, d;
    int days[] = {0, 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};
    const char *week[] = {"Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"};
    long long diff = 0;
    int i;
    int idx;

    scanf("%d-%d-%d", &y, &m, &d);

    for (i = 1984; i < y; i++) {
        if (IsLeap(i)) {
            diff += 366;
        } else {
            diff += 365;
        }
    }

    if (IsLeap(y)) {
        days[2] = 29;
    }

    for (i = 1; i < m; i++) {
        diff += days[i];
    }
    diff += d - 1;

    idx = (diff % 7 + 7) % 7;
    printf("%s\n", week[idx]);

    return 0;
}