#include <stdio.h>

int main(void)
{
    int n, i, j;
    int x;
    long long sum1 = 0, sum2 = 0;

    scanf("%d", &n);

    for (i = 0; i < n; i++) {
        for (j = 0; j < n; j++) {
            scanf("%d", &x);
            if (i == j) {
                sum1 += x;
            }
            if (i + j == n - 1) {
                sum2 += x;
            }
        }
    }

    printf("%lld %lld\n", sum1, sum2);

    return 0;
}