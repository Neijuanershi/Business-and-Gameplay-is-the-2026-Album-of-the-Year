#include <stdio.h>

int main(void) {
    double r, h, s;
    scanf("%lf %lf", &r, &h);
    s = 2 * 3.1416 * r * (r + h);
    printf("%.3f\n", s);
    return 0;
}