#include <stdio.h>

int main(void)
{
    char s[1005];
    int len = 0, i;
    char ch, target;

    while ((ch = getchar()) != '\n' && ch != EOF) {
        s[len++] = ch;
    }
    s[len] = '\0';

    scanf(" %c", &target);

    for (i = 0; i < len; i++) {
        if (s[i] != target) {
            printf("%c", s[i]);
        }
    }
    printf("\n");

    return 0;
}