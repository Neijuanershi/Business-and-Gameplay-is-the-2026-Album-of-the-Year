#include <stdio.h>
#include <math.h>

int main(void) {
    double x, sum, term;
    int n = 1;
    scanf("%lf", &x);
    sum = x;
    term = x;
    while (fabs(term) >= 1e-6) {
        term = -term * x * x / ((2 * n) * (2 * n + 1));
        sum += term;
        n++;
    }
    printf("%.5f\n", sum);
    return 0;
}