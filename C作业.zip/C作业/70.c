#include <stdio.h>

int main(void)
{
    double amount;
    double total = 0.0;
    int count = 0;

    while (scanf("%lf", &amount) == 1) {
        total += amount;
        count++;
        if (total >= 10000.0) {
            break;
        }
    }

    printf("%d %.2f\n", count, total / count);

    return 0;
}