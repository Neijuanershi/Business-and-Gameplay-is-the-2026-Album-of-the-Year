#include <stdio.h>

int main(void)
{
    int n, m, p, i, j, k;
    scanf("%d %d %d", &n, &m, &p);

    int a[n][m];
    int b[m][p];
    int c[n][p];

    for (i = 0; i < n; i++) {
        for (j = 0; j < m; j++) {
            scanf("%d", &a[i][j]);
        }
    }

    for (i = 0; i < m; i++) {
        for (j = 0; j < p; j++) {
            scanf("%d", &b[i][j]);
        }
    }

    for (i = 0; i < n; i++) {
        for (j = 0; j < p; j++) {
            c[i][j] = 0;
            for (k = 0; k < m; k++) {
                c[i][j] += a[i][k] * b[k][j];
            }
        }
    }

    for (i = 0; i < n; i++) {
        for (j = 0; j < p; j++) {
            if (j > 0) {
                printf(" ");
            }
            printf("%d", c[i][j]);
        }
        printf("\n");
    }

    return 0;
}