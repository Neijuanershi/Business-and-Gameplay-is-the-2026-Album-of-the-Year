#include <stdio.h>

int main(void) {
    int i, fact = 1, sum = 0;
    for (i = 1; i <= 6; i++) {
        fact *= i;
        sum += fact;
    }
    printf("%d\n", sum);
    return 0;
}