#include <stdio.h>

int main(void) {
    int i, sum = 0;
    for (i = 800; i <= 900; i++) {
        if (i % 2 == 0) {
            sum += i;
        }
    }
    printf("%d\n", sum);
    return 0;
}