#include <stdio.h>

int main(void)
{
    int score;
    int fail_scores[105];
    int count = 0;
    int fail_count = 0;
    int i;

    while (scanf("%d", &score) == 1 && score != 0) {
        if (score < 60) {
            fail_scores[fail_count++] = score;
        }
        count++;
    }

    for (i = 0; i < fail_count; i++) {
        if (i > 0) {
            printf(" ");
        }
        printf("%d", fail_scores[i]);
    }
    printf("\n");

    if (count > 0) {
        printf("%.2f\n", (double)fail_count / count * 100.0);
    } else {
        printf("0.00\n");
    }

    return 0;
}