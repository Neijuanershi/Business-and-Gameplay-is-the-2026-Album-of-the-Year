#include <stdio.h>

int main(void)
{
    char ch;
    int last_space = 0;

    while ((ch = getchar()) != '\n' && ch != EOF) {
        if (ch == ' ') {
            if (!last_space) {
                putchar(ch);
                last_space = 1;
            }
        } else {
            putchar(ch);
            last_space = 0;
        }
    }
    printf("\n");

    return 0;
}