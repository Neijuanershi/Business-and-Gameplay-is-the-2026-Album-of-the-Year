#include <stdio.h>

int main(void)
{
    int a[3][4] = {0};
    int x, i, j;

    for (i = 0; i < 10; i++) {
        scanf("%d", &x);
        a[i / 4][i % 4] = x;
    }

    for (i = 0; i < 3; i++) {
        for (j = 0; j < 4; j++) {
            if (j > 0) {
                printf(" ");
            }
            printf("%d", a[i][j]);
        }
        printf("\n");
    }

    return 0;
}