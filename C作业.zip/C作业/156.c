
#include <stdio.h>
#include <string.h>

char orig[1000005];
char trans[1000005];
char target[1000005];
int mp[256];

int main(void)
{
    int i;
    int len_orig, len_trans, len_target;
    int len;
    for (i = 0; i < 256; i++) mp[i] = -1;
    if (fgets(orig, sizeof(orig), stdin) == NULL) return 0;
    if (fgets(trans, sizeof(trans), stdin) == NULL) return 0;
    if (fgets(target, sizeof(target), stdin) == NULL) strcpy(target, "xabxdcc23y1");
    len = strlen(orig);
    while (len > 0 && (orig[len - 1] == '\n' || orig[len - 1] == '\r')) orig[--len] = '\0';
    len = strlen(trans);
    while (len > 0 && (trans[len - 1] == '\n' || trans[len - 1] == '\r')) trans[--len] = '\0';
    len = strlen(target);
    while (len > 0 && (target[len - 1] == '\n' || target[len - 1] == '\r')) target[--len] = '\0';
    if (target[0] == '\0') strcpy(target, "xabxdcc23y1");
    len_orig = strlen(orig);
    len_trans = strlen(trans);
    len_target = strlen(target);
    for (i = 0; i < len_trans; i++) {
        unsigned char c = (unsigned char)trans[i];
        if (mp[c] == -1) mp[c] = i;
    }
    for (i = 0; i < len_target; i++) {
        int idx = mp[(unsigned char)target[i]];
        putchar((idx != -1 && idx < len_orig) ? orig[idx] : '_');
    }
    putchar('\n');
    return 0;
}