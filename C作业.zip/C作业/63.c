#include <stdio.h>
#include <math.h>

int main(void) {
    double x0 = 1.5, x1, fx, fpx;
    do {
        fx = 2 * x0 * x0 * x0 - 4 * x0 * x0 + 3 * x0 - 6;
        fpx = 6 * x0 * x0 - 8 * x0 + 3;
        x1 = x0 - fx / fpx;
        if (fabs(x1 - x0) < 1e-6) {
            break;
        }
        x0 = x1;
    } while (1);
    printf("%.5f\n", x1);
    return 0;
}