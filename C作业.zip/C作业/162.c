#include <stdio.h>

char s[1000005];
char out1[1000005];
char out2[1000005];

int main(void)
{
    int i;
    int len;
    int first;
    int second;
    int p;
    int q;
    if (fgets(s, sizeof(s), stdin) == NULL) {
        printf("\n\n");
        return 0;
    }
    i = 0;
    first = -1;
    second = -1;
    while (s[i] != '\0' && s[i] != '\n' && s[i] != '\r') {
        if (s[i] == 'a') {
            if (first == -1) {
                first = i;
            } else if (second == -1) {
                second = i;
            }
        }
        i++;
    }
    len = i;
    if (first == -1 || second == -1) {
        printf("\n\n");
        return 0;
    }
    p = 0;
    for (i = 0; i < first; i++) {
        out1[p++] = s[i];
    }
    for (i = second + 1; i < len; i++) {
        out1[p++] = s[i];
    }
    out1[p] = '\0';
    q = 0;
    for (i = first + 1; i < second; i++) {
        out2[q++] = s[i];
    }
    out2[q] = '\0';
    printf("%s\n", out1);
    printf("%s\n", out2);
    return 0;
}