#include <stdio.h>

int main(void)
{
    char s[100];
    int i, ans = 0;
    
    scanf("%s", s);
    
    for (i = 0; s[i] != '\0'; i++) {
        ans = ans * 2 + (s[i] - '0');
    }
    
    printf("%d\n", ans);
    
    return 0;
}