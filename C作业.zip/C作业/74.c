#include <stdio.h>

int main(void)
{
    int i, temp, count;
    int first = 1;

    for (i = 1; i <= 1000; i++) {
        if (i % 13 == 0) {
            temp = i;
            count = 0;
            while (temp > 0) {
                if (temp % 10 == 7) {
                    count++;
                }
                temp /= 10;
            }
            if (count >= 2) {
                if (!first) {
                    printf(" ");
                }
                printf("%d", i);
                first = 0;
            }
        }
    }
    printf("\n");

    return 0;
}