#include <stdio.h>

int main(void)
{
    int i, x;
    int sum = 0;

    for (i = 0; i < 10; i++) {
        scanf("%d", &x);
        sum += x;
    }

    printf("%d %.2f\n", sum, sum / 10.0);

    return 0;
}