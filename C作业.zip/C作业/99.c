#include <stdio.h>

int main(void)
{
    int a[8];
    int i, j, temp;

    for (i = 0; i < 8; i++) {
        scanf("%d", &a[i]);
    }

    for (i = 0; i < 7; i++) {
        for (j = 0; j < 7 - i; j++) {
            if (a[j] < a[j + 1]) {
                temp = a[j];
                a[j] = a[j + 1];
                a[j + 1] = temp;
            }
        }
    }

    for (i = 0; i < 8; i++) {
        if (i > 0) {
            printf(" ");
        }
        printf("%d", a[i]);
    }
    printf("\n");

    return 0;
}