#include <stdio.h>

int main(void) {
    int n, a, b, c, rev, sum;
    scanf("%d", &n);
    a = n / 100;
    b = (n / 10) % 10;
    c = n % 10;
    rev = c * 100 + b * 10 + a;
    sum = n + rev;
    printf("%d\n", sum);
    return 0;
}