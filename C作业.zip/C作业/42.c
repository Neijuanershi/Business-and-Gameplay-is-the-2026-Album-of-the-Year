#include <stdio.h>

int main(void) {
    int x, max1, max2;
    int i;

    scanf("%d", &x);
    max1 = x;

    scanf("%d", &x);
    if (x > max1) {
        max2 = max1;
        max1 = x;
    } else {
        max2 = x;
    }

    for (i = 2; i < 10; i++) {
        scanf("%d", &x);
        if (x > max1) {
            max2 = max1;
            max1 = x;
        } else if (x > max2) {
            max2 = x;
        }
    }

    printf("%d %d\n", max1, max2);
    return 0;
}