#include <stdio.h>

int main(void)
{
    long long n;
    scanf("%lld", &n);
    printf("%lld", n);

    while (n >= 10) {
        long long prod = 1;
        long long temp = n;
        while (temp > 0) {
            prod *= temp % 10;
            temp /= 10;
        }
        n = prod;
        printf(" %lld", n);
    }
    printf("\n");

    return 0;
}