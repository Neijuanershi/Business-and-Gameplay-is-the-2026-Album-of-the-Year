#include <stdio.h>

int main(void) {
    int start, end, sum, i;

    for (start = 1; start <= 500; start++) {
        sum = 0;
        for (end = start; end <= 500; end++) {
            sum += end;
            if (sum == 500) {
                if (start < end) {
                    for (i = start; i <= end; i++) {
                        printf("%d", i);
                        if (i < end) {
                            printf(" ");
                        }
                    }
                    printf("\n");
                }
                break;
            } else if (sum > 500) {
                break;
            }
        }
    }

    return 0;
}