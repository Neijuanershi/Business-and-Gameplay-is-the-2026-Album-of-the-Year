#include <stdio.h>

int main(void) {
    int n;
    int digits[10];
    int count = 0;
    int i;

    scanf("%d", &n);

    while (n > 0) {
        digits[count] = n % 10;
        count++;
        n /= 10;
    }

    for (i = count - 1; i >= 0; i--) {
        printf("%d", digits[i]);
        if (i > 0) {
            printf(" ");
        }
    }
    printf("\n");

    return 0;
}