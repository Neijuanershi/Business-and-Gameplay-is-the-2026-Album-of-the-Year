#include <stdio.h>

int main(void)
{
    int sq[30], cnt = 0;
    int i, j, k, t, d, p;
    int used[10], ok, nums[3];

    for (i = 11; i <= 31; i++) {
        t = i * i;
        for (p = 0; p < 10; p++) {
            used[p] = 0;
        }
        ok = 1;
        while (t > 0) {
            d = t % 10;
            if (d == 0 || used[d]) {
                ok = 0;
                break;
            }
            used[d] = 1;
            t /= 10;
        }
        if (ok) {
            sq[cnt++] = i * i;
        }
    }

    for (i = 0; i < cnt; i++) {
        for (j = 0; j < cnt; j++) {
            if (j == i) {
                continue;
            }
            for (k = 0; k < cnt; k++) {
                if (k == i || k == j) {
                    continue;
                }
                for (p = 0; p < 10; p++) {
                    used[p] = 0;
                }
                nums[0] = sq[i];
                nums[1] = sq[j];
                nums[2] = sq[k];
                ok = 1;
                for (p = 0; p < 3; p++) {
                    t = nums[p];
                    while (t > 0) {
                        d = t % 10;
                        if (used[d]) {
                            ok = 0;
                            break;
                        }
                        used[d] = 1;
                        t /= 10;
                    }
                    if (!ok) {
                        break;
                    }
                }
                if (ok) {
                    printf("%d %d %d\n", sq[i], sq[j], sq[k]);
                    return 0;
                }
            }
        }
    }

    return 0;
}