#include <stdio.h>

int main(void) {
    int a = 1, b = 1, sum = 0, temp;
    int i;
    for (i = 1; i <= 20; i++) {
        sum += a;
        temp = a + b;
        a = b;
        b = temp;
    }
    printf("%d\n", sum);
    return 0;
}