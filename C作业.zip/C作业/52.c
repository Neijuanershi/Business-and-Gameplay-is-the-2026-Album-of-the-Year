#include <stdio.h>

int main(void) {
    int m, i, is_prime = 1;
    scanf("%d", &m);
    for (i = 2; i * i <= m; i++) {
        if (m % i == 0) {
            is_prime = 0;
            break;
        }
    }
    if (is_prime) {
        printf("Yes\n");
    } else {
        printf("No\n");
    }
    return 0;
}