#include <stdio.h>

int main(void)
{
    int n, i;
    int a[1005];
    int l1, r1, l2, r2;
    int temp1[1005], temp2[1005];
    int len1, len2;

    scanf("%d", &n);
    for (i = 0; i < n; i++) {
        scanf("%d", &a[i]);
    }
    scanf("%d %d", &l1, &r1);
    scanf("%d %d", &l2, &r2);

    len1 = r1 - l1 + 1;
    len2 = r2 - l2 + 1;

    for (i = 0; i < len1; i++) {
        temp1[i] = a[l1 - 1 + i];
    }
    for (i = 0; i < len2; i++) {
        temp2[i] = a[l2 - 1 + i];
    }

    for (i = 0; i < len1; i++) {
        a[l1 - 1 + i] = temp2[i];
    }
    for (i = 0; i < len2; i++) {
        a[l2 - 1 + i] = temp1[i];
    }

    for (i = 0; i < n; i++) {
        if (i > 0) {
            printf(" ");
        }
        printf("%d", a[i]);
    }
    printf("\n");

    return 0;
}