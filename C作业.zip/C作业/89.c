#include <stdio.h>

int main(void)
{
    int a[10];
    int i, temp;

    for (i = 0; i < 10; i++) {
        scanf("%d", &a[i]);
    }

    for (i = 0; i < 5; i++) {
        temp = a[i];
        a[i] = a[9 - i];
        a[9 - i] = temp;
    }

    for (i = 0; i < 10; i++) {
        if (i > 0) {
            printf(" ");
        }
        printf("%d", a[i]);
    }
    printf("\n");

    return 0;
}