#include <stdio.h>

char s[1000005];
char letters[1000005];
char digits[1000005];

int main(void)
{
    int i = 0, j = 0, k = 0;
    if (fgets(s, sizeof(s), stdin) == NULL) {
        printf("\n\n");
        return 0;
    }
    while (s[i] != '\0') {
        char c = s[i];
        if ((c >= 'A' && c <= 'Z') || (c >= 'a' && c <= 'z')) {
            letters[j++] = c;
        } else if (c >= '0' && c <= '9') {
            digits[k++] = c;
        }
        i++;
    }
    letters[j] = '\0';
    digits[k] = '\0';
    printf("%s\n", letters);
    printf("%s\n", digits);
    return 0;
}