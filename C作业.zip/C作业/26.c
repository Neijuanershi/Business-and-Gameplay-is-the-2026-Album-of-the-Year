#include <stdio.h>

int main(void) {
    int h1, m1, s1, h2, m2, s2;
    int t1, t2, diff, dh, dm, ds;
    scanf("%d:%d:%d %d:%d:%d", &h1, &m1, &s1, &h2, &m2, &s2);
    t1 = h1 * 3600 + m1 * 60 + s1;
    t2 = h2 * 3600 + m2 * 60 + s2;
    diff = t2 - t1;
    dh = diff / 3600;
    dm = (diff % 3600) / 60;
    ds = diff % 60;
    printf("%02d:%02d:%02d ", dh, dm, ds);
    if (diff > 7200) {
        printf("NO\n");
    } else {
        printf("OK\n");
    }
    return 0;
}   