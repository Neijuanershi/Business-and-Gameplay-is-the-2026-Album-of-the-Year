#include <stdio.h>

int main(void) {
    double scores[10];
    double sum = 0.0, max, min, avg;
    int i;

    for (i = 0; i < 10; i++) {
        scanf("%lf", &scores[i]);
    }

    max = scores[0];
    min = scores[0];

    for (i = 0; i < 10; i++) {
        sum += scores[i];
        if (scores[i] > max) {
            max = scores[i];
        }
        if (scores[i] < min) {
            min = scores[i];
        }
    }

    avg = (sum - max - min) / 8.0;
    printf("%.3f %.3f %.3f\n", max, min, avg);

    return 0;
}