#include <stdio.h>

int main(void)
{
    char s1[1005], s2[1005];
    int len1 = 0, len2 = 0, i = 0;
    char ch;

    while ((ch = getchar()) != '\n' && ch != EOF) {
        s1[len1++] = ch;
    }
    s1[len1] = '\0';

    while ((ch = getchar()) != '\n' && ch != EOF) {
        s2[len2++] = ch;
    }
    s2[len2] = '\0';

    while (s1[i] != '\0' && s2[i] != '\0' && s1[i] == s2[i]) {
        i++;
    }

    if (s1[i] > s2[i]) {
        printf("1\n");
    } else if (s1[i] < s2[i]) {
        printf("-1\n");
    } else {
        printf("0\n");
    }

    return 0;
}