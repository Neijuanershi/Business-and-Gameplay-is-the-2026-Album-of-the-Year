#include <stdio.h>

int main(void)
{
    int n;
    int a, b, c, d, ans;
    
    scanf("%d", &n);
    
    a = n / 1000;
    b = (n / 100) % 10;
    c = (n / 10) % 10;
    d = n % 10;
    
    a = (a + 5) % 10;
    b = (b + 5) % 10;
    c = (c + 5) % 10;
    d = (d + 5) % 10;
    
    ans = d * 1000 + c * 100 + b * 10 + a;
    
    printf("%d\n", ans);
    
    return 0;
}