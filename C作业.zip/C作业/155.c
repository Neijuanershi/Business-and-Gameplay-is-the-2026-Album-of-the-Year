#include <stdio.h>

int main(void)
{
    char ch;

    while ((ch = getchar()) != '\n' && ch != EOF) {
        if (ch >= 'a' && ch <= 'z') {
            ch = 'a' + (ch - 'a' + 4) % 26;
        } else if (ch >= 'A' && ch <= 'Z') {
            ch = 'A' + (ch - 'A' + 4) % 26;
        }
        putchar(ch);
    }
    printf("\n");

    return 0;
}