#include <stdio.h>

int main(void)
{
    int n, i, j;
    int x;
    long long prod1 = 1, prod2 = 1;

    scanf("%d", &n);

    for (i = 0; i < n; i++) {
        for (j = 0; j < n; j++) {
            scanf("%d", &x);
            if (i == j) {
                prod1 *= x;
            }
            if (i + j == n - 1) {
                prod2 *= x;
            }
        }
    }

    printf("%lld %lld\n", prod1, prod2);

    return 0;
}