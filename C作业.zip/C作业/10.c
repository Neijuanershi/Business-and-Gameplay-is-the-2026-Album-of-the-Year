#include <stdio.h>

int main(void) {
    long long n, m, ans;
    scanf("%lld %lld", &n, &m);
    ans = (n / m) * (n / m);
    printf("%lld\n", ans);
    return 0;
}