#include <stdio.h>

char src[1000005];
char dst[1000005];

int main(void)
{
    int i = 0;
    if (fgets(src, sizeof(src), stdin) == NULL) return 0;
    while (src[i] != '\0') {
        dst[i] = src[i];
        i++;
    }
    dst[i] = '\0';
    while (i > 0 && (dst[i - 1] == '\n' || dst[i - 1] == '\r')) {
        dst[i - 1] = '\0';
        i--;
    }
    printf("%s\n", dst);
    return 0;
}