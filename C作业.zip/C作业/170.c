#include <stdio.h>

char s[1000005];

int main(void)
{
    int i = 0;
    int count = 0;
    int inWord = 0;
    if (fgets(s, sizeof(s), stdin) == NULL) {
        printf("0\n");
        return 0;
    }
    while (s[i] != '\0' && s[i] != '\n' && s[i] != '\r') {
        if (s[i] == ' ' || s[i] == '\t') {
            inWord = 0;
        } else {
            if (!inWord) {
                count++;
                inWord = 1;
            }
        }
        i++;
    }
    printf("%d\n", count);
    return 0;
}