#include <stdio.h>

int main(void)
{
    int n;
    for (n = 81; n <= 342; n++) {
        int a = n / 49;
        int b = (n / 7) % 7;
        int c = n % 7;
        int x = n / 81;
        int y = (n / 9) % 9;
        int z = n % 9;
        if (a == z && b == y && c == x) {
            printf("%d\n", n);
        }
    }
    return 0;
}