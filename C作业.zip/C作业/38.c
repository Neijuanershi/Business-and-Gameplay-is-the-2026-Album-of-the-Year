#include <stdio.h>

int main(void) {
    int c;
    int letters = 0, digits = 0, others = 0;
    while ((c = getchar()) != '\n' && c != EOF) {
        if ((c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z')) {
            letters++;
        } else if (c >= '0' && c <= '9') {
            digits++;
        } else {
            others++;
        }
    }
    printf("%d %d %d\n", letters, digits, others);
    return 0;
}