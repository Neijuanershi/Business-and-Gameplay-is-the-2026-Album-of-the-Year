#include <stdio.h>

int a[1005][1005];

int main(void)
{
    int n, i, j;
    scanf("%d", &n);
    
    int r = n / 2, c = n - 1;
    for (i = 1; i <= n * n; i++) {
        a[r][c] = i;
        int nr = (r + 1) % n;
        int nc = (c + 1) % n;
        if (a[nr][nc] != 0) {
            nr = r;
            nc = (c - 1 + n) % n;
        }
        r = nr;
        c = nc;
    }
    
    for (i = 0; i < n; i++) {
        for (j = 0; j < n; j++) {
            if (j > 0) {
                printf(" ");
            }
            printf("%d", a[i][j]);
        }
        printf("\n");
    }
    
    return 0;
}