#include <stdio.h>

int main(void)
{
    int n, m, i, j;
    int a[105][105];
    int max_val = -1, max_r = 0, max_c = 0;
    long long sum = 0;

    scanf("%d %d", &n, &m);

    for (i = 0; i < n; i++) {
        for (j = 0; j < m; j++) {
            scanf("%d", &a[i][j]);
            if (a[i][j] > max_val) {
                max_val = a[i][j];
                max_r = i;
                max_c = j;
            }
        }
    }

    for (i = 0; i <= max_r; i++) {
        sum += a[i][0];
    }

    for (j = 1; j <= max_c; j++) {
        sum += a[max_r][j];
    }

    printf("%lld\n", sum);

    return 0;
}