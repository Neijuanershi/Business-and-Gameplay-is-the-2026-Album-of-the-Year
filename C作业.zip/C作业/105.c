#include <stdio.h>

int main(void)
{
    unsigned int n;
    scanf("%u", &n);
    printf("%X\n", n);
    return 0;
}