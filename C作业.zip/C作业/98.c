#include <stdio.h>

int main(void)
{
    int a[10];
    int i, max;
    int first = 1;

    for (i = 0; i < 10; i++) {
        scanf("%d", &a[i]);
    }

    max = a[0];
    for (i = 1; i < 10; i++) {
        if (a[i] > max) {
            max = a[i];
        }
    }

    for (i = 0; i < 10; i++) {
        if (a[i] != max) {
            if (!first) {
                printf(" ");
            }
            printf("%d", a[i]);
            first = 0;
        }
    }
    printf("\n");

    return 0;
}