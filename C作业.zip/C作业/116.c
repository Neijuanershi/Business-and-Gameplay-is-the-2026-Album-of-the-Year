#include <stdio.h>

int main(void)
{
    long long n, k = 1, pos, num, den;
    scanf("%lld", &n);

    while (k * (k + 1) / 2 < n) {
        k++;
    }

    pos = n - k * (k - 1) / 2;

    if (k % 2 == 1) {
        num = k - pos + 1;
        den = pos;
    } else {
        num = pos;
        den = k - pos + 1;
    }

    printf("%lld/%lld\n", num, den);

    return 0;
}