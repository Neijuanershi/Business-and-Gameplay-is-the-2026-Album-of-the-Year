#include <stdio.h>

int main(void) {
    int n;
    for (n = 900; n <= 1100; n++) {
        if (n % 7 == 3 && n % 5 == 2 && n % 3 == 1) {
            printf("%d\n", n);
            break;
        }
    }
    return 0;
}