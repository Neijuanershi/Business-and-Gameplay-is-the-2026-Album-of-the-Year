#include <stdio.h>

char s[1000005];
char out[1000005];

int main(void)
{
    int len = 0;
    int n;
    char c;
    int i;
    int p = 0;
    if (fgets(s, sizeof(s), stdin) == NULL) {
        printf("\n");
        return 0;
    }
    while (s[len] != '\0' && s[len] != '\n' && s[len] != '\r') len++;
    if (scanf("%d %c", &n, &c) != 2) {
        printf("\n");
        return 0;
    }
    if (n < 0) n = 0;
    if (n > len) n = len;
    for (i = 0; i < n; i++) out[p++] = s[i];
    out[p++] = c;
    for (i = n; i < len; i++) out[p++] = s[i];
    out[p] = '\0';
    printf("%s\n", out);
    return 0;
}   