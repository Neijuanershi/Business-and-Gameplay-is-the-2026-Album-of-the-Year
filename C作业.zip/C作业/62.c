#include <stdio.h>

double f(double x) {
    return 2 * x * x * x - 4 * x * x + 3 * x - 6;
}

int main(void) {
    double low = -10.0, high = 10.0, mid;
    while (high - low > 1e-7) {
        mid = (low + high) / 2.0;
        if (f(mid) < 0) {
            low = mid;
        } else {
            high = mid;
        }
    }
    printf("%.5f\n", mid);
    return 0;
}