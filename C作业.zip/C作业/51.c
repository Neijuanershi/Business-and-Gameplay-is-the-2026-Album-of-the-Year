#include <stdio.h>
#include <math.h>

int main(void) {
    int x, a, b;
    int first = 1;
    for (x = 0; x <= 10000; x++) {
        a = (int)sqrt(x + 100);
        b = (int)sqrt(x + 268);
        if (a * a == x + 100 && b * b == x + 268) {
            if (!first) {
                printf(" ");
            }
            printf("%d", x);
            first = 0;
        }
    }
    printf("\n");
    return 0;
}