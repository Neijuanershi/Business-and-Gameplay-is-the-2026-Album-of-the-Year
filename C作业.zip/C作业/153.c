#include <stdio.h>

int main(void)
{
    char s[1005];
    int len = 0;
    char ch;
    int k, n, i;

    while ((ch = getchar()) != '\n' && ch != EOF) {
        s[len++] = ch;
    }
    s[len] = '\0';

    scanf("%d %d", &k, &n);

    for (i = 0; i < len; i++) {
        if (i + 1 >= k && i + 1 < k + n) {
            continue;
        }
        printf("%c", s[i]);
    }
    printf("\n");

    return 0;
}