#include <stdio.h>

int main(void) {
    int a, b, c, temp;
    scanf("%d %d %d", &a, &b, &c);
    if (a > b) {
        temp = a;
        a = b;
        b = temp;
    }
    if (a > c) {
        temp = a;
        a = c;
        c = temp;
    }
    if (b > c) {
        temp = b;
        b = c;
        c = temp;
    }
    if (b == a + 1 && c == b + 1) {
        printf("Yes\n");
    } else {
        printf("No\n");
    }
    return 0;
}