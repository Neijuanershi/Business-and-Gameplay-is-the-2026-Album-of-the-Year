#include <stdio.h>

int main(void)
{
    int m, n, i, j, x;
    int a[50][50];
    int score = 0;

    scanf("%d %d", &m, &n);

    for (i = 0; i < m; i++) {
        for (j = 0; j < n; j++) {
            scanf("%d", &a[i][j]);
        }
    }

    for (i = 0; i < m; i++) {
        for (j = 0; j < n; j++) {
            scanf("%d", &x);
            if (x == a[i][j]) {
                score++;
            }
        }
    }

    printf("%d\n", score);

    return 0;
}