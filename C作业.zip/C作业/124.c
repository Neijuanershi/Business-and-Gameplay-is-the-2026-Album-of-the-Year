#include <stdio.h>

int main(void)
{
    int counts[11] = {0};
    int ids[10] = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10};
    int i, j, temp;
    int vote;

    for (i = 0; i < 20; i++) {
        scanf("%d", &vote);
        if (vote >= 1 && vote <= 10) {
            counts[vote]++;
        }
    }

    for (i = 0; i < 9; i++) {
        for (j = 0; j < 9 - i; j++) {
            if (counts[ids[j]] < counts[ids[j + 1]] || 
                (counts[ids[j]] == counts[ids[j + 1]] && ids[j] > ids[j + 1])) {
                temp = ids[j];
                ids[j] = ids[j + 1];
                ids[j + 1] = temp;
            }
        }
    }

    for (i = 0; i < 10; i++) {
        printf("%d %d\n", ids[i], counts[ids[i]]);
    }

    return 0;
}