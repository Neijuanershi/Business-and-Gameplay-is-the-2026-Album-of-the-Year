#include <stdio.h>

char s[1000005];

int main(void)
{
    int len = 0;
    if (fgets(s, sizeof(s), stdin) == NULL) {
        printf("0\n");
        return 0;
    }
    while (s[len] != '\0') len++;
    while (len > 0 && (s[len - 1] == '\n' || s[len - 1] == '\r')) len--;
    printf("%d\n", len);
    return 0;
}