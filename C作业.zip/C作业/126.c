#include <stdio.h>

int main(void)
{
    int n, m, i, j;
    scanf("%d %d", &n, &m);

    int a[n][m];
    int rowmax[n];
    int colmin[m];

    for (i = 0; i < n; i++) {
        for (j = 0; j < m; j++) {
            scanf("%d", &a[i][j]);
        }
    }

    for (i = 0; i < n; i++) {
        rowmax[i] = a[i][0];
        for (j = 1; j < m; j++) {
            if (a[i][j] > rowmax[i]) {
                rowmax[i] = a[i][j];
            }
        }
    }

    for (j = 0; j < m; j++) {
        colmin[j] = a[0][j];
        for (i = 1; i < n; i++) {
            if (a[i][j] < colmin[j]) {
                colmin[j] = a[i][j];
            }
        }
    }

    int found = 0;
    for (i = 0; i < n; i++) {
        for (j = 0; j < m; j++) {
            if (a[i][j] == rowmax[i] && a[i][j] == colmin[j]) {
                printf("%d\n", a[i][j]);
                found = 1;
                break;
            }
        }
        if (found) {
            break;
        }
    }

    if (!found) {
        printf("No\n");
    }

    return 0;
}