#include <stdio.h>

int main(void) {
    long long n, m, x, y;
    scanf("%lld %lld", &n, &m);
    y = (m - 2 * n) / 2;
    x = n - y;
    if (m % 2 != 0 || x < 0 || y < 0) {
        printf("ERROR\n");
    } else {
        printf("%lld %lld\n", x, y);
    }
    return 0;
}