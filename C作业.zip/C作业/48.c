#include <stdio.h>

int main(void) {
    int i, j, k, count = 0;
    for (i = 1; i <= 4; i++) {
        for (j = 1; j <= 4; j++) {
            for (k = 1; k <= 4; k++) {
                if (i != j && j != k && i != k) {
                    count++;
                    printf("%d%d%d", i, j, k);
                    if (count % 6 == 0) {
                        printf("\n");
                    } else {
                        printf(" ");
                    }
                }
            }
        }
    }
    return 0;
}