#include <stdio.h>

int main(void) {
    int x, y;
    for (x = -44; x <= 44; x++) {
        for (y = -44; y <= 44; y++) {
            if (x * x + y * y == 2017) {
                printf("%d %d\n", x, y);
            }
        }
    }
    return 0;
}