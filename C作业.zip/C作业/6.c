#include <stdio.h>

int main(void) {
    int a, b, c, sum;
    double average;
    scanf("%d %d %d", &a, &b, &c);
    sum = a + b + c;
    average = sum / 3.0;
    printf("%d %.2f\n", sum, average);
    return 0;
}