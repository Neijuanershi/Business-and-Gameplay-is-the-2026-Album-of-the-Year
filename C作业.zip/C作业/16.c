#include <stdio.h>

int main(void) {
    double x;
    scanf("%lf", &x);
    if (x < 0) {
        x = -x;
    }
    printf("%.2f\n", x);
    return 0;
}