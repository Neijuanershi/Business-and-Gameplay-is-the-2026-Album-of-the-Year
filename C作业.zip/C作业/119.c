#include <stdio.h>

int main(void)
{
    int a[3][4];
    int b[12];
    int i, j, k = 0;

    for (i = 0; i < 3; i++) {
        for (j = 0; j < 4; j++) {
            scanf("%d", &a[i][j]);
            b[k++] = a[i][j];
        }
    }

    for (i = 0; i < 12; i++) {
        if (i > 0) {
            printf(" ");
        }
        printf("%d", b[i]);
    }
    printf("\n");

    return 0;
}