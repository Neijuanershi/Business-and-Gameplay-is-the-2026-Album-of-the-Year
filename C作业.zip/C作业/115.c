#include <stdio.h>

int main(void)
{
    int n, i, j, r, c, r_start, r_end;
    scanf("%d %d %d", &n, &i, &j);

    for (c = 1; c <= n; c++) {
        printf("(%d,%d)", i, c);
    }
    printf("\n");

    for (r = 1; r <= n; r++) {
        printf("(%d,%d)", r, j);
    }
    printf("\n");

    r_start = (1 + i - j > 1) ? 1 + i - j : 1;
    r_end = (n + i - j < n) ? n + i - j : n;
    for (r = r_start; r <= r_end; r++) {
        printf("(%d,%d)", r, r + j - i);
    }
    printf("\n");

    r_start = (i + j - n > 1) ? i + j - n : 1;
    r_end = (i + j - 1 < n) ? i + j - 1 : n;
    for (r = r_end; r >= r_start; r--) {
        printf("(%d,%d)", r, i + j - r);
    }
    printf("\n");

    return 0;
}