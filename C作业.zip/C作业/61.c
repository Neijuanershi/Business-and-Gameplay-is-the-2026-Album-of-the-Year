#include <stdio.h>

int main(void) {
    int n, i;
    long long term = 1, sum = 0;
    scanf("%d", &n);
    for (i = 1; i <= n; i++) {
        term = term * 2 * i;
        sum += term;
    }
    printf("%lld\n", sum);
    return 0;
}