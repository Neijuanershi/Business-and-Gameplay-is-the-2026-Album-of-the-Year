#include <stdio.h>

int main(void) {
    long long n;
    scanf("%lld", &n);
    long long first = 8;
    long long second = (n - 2) * 12;
    long long third = (n - 2) * (n - 2) * 6;
    printf("%lld %lld %lld\n", first, second, third);
    return 0;
}