#include <stdio.h>

int main(void)
{
    long long n;
    int count_zero = 0;
    int max_digit = 0;

    scanf("%lld", &n);

    while (n > 0) {
        int digit = n % 10;
        if (digit == 0) {
            count_zero++;
        } else if (digit > max_digit) {
            max_digit = digit;
        }
        n = n / 10;
    }

    printf("%d %d\n", count_zero, max_digit);

    return 0;
}