#include <stdio.h>

int main(void)
{
    int n, i;
    int a[1005];
    int first = 1;

    scanf("%d", &n);
    for (i = 0; i < n; i++) {
        scanf("%d", &a[i]);
    }

    for (i = 1; i < n - 1; i++) {
        if (a[i] > a[i - 1] && a[i] > a[i + 1]) {
            if (!first) {
                printf(" ");
            }
            printf("%d", a[i]);
            first = 0;
        }
    }
    printf("\n");

    return 0;
}