#include <stdio.h>

int main(void) {
    int h, m;
    double ha, ma, angle;
    scanf("%d:%d", &h, &m);
    ha = (h % 12) * 30 + m * 0.5;
    ma = m * 6;
    angle = ha - ma;
    if (angle < 0) {
        angle = -angle;
    }
    if (angle > 180) {
        angle = 360 - angle;
    }
    printf("%.2f\n", angle);
    return 0;
}