#include <stdio.h>
#include <math.h>

int main(void) {
    double a, x0, x1;
    scanf("%lf", &a);
    x0 = a / 2.0;
    x1 = (x0 + a / x0) / 2.0;
    while (fabs(x1 - x0) >= 1e-5) {
        x0 = x1;
        x1 = (x0 + a / x0) / 2.0;
    }
    printf("%.4f\n", x1);
    return 0;
}