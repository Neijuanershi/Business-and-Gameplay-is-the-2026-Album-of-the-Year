#include <stdio.h>

int main(void)
{
    int i, a, b, c;
    int first = 1;

    for (i = 100; i <= 999; i++) {
        a = i / 100;
        b = (i / 10) % 10;
        c = i % 10;
        if (a * a * a + b * b * b + c * c * c == i) {
            if (!first) {
                printf(" ");
            }
            printf("%d", i);
            first = 0;
        }
    }
    printf("\n");

    return 0;
}