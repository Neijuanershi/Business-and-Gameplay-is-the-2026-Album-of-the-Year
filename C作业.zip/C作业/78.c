#include <stdio.h>

int main(void)
{
    int a, b, x, y, temp, gcd, lcm;
    scanf("%d %d", &a, &b);
    x = a;
    y = b;
    while (y != 0) {
        temp = x % y;
        x = y;
        y = temp;
    }
    gcd = x;
    lcm = (a / gcd) * b;
    printf("%d %d\n", gcd, lcm);
    return 0;
}