#include <stdio.h>

int main(void) {
    int ladders;
    for (ladders = 7; ; ladders += 14) {
        if (ladders % 3 == 2 && ladders % 5 == 4 && ladders % 6 == 5) {
            printf("%d\n", ladders);
            break;
        }
    }
    return 0;
}