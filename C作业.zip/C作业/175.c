#include <stdio.h>
#include <string.h>

char a[1000005];
char b[1000005];
char res[1000005];

int main(void)
{
    int la = 0, lb = 0;
    int i, j, k;
    int carry = 0;
    int sum;
    if (fgets(a, sizeof(a), stdin) == NULL) {
        printf("0\n");
        return 0;
    }
    if (fgets(b, sizeof(b), stdin) == NULL) {
        printf("0\n");
        return 0;
    }
    while (a[la] != '\0' && a[la] != '\n' && a[la] != '\r') la++;
    while (b[lb] != '\0' && b[lb] != '\n' && b[lb] != '\r') lb++;
    i = la - 1;
    j = lb - 1;
    k = 0;
    while (i >= 0 || j >= 0 || carry) {
        sum = carry;
        if (i >= 0) sum += a[i] - '0';
        if (j >= 0) sum += b[j] - '0';
        carry = sum / 10;
        res[k++] = (char)('0' + sum % 10);
        i--;
        j--;
    }
    while (k > 1 && res[k - 1] == '0') k--;
    for (i = k - 1; i >= 0; i--) putchar(res[i]);
    putchar('\n');
    return 0;
}