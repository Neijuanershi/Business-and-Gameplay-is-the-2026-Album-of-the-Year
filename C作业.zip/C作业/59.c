#include <stdio.h>

int main(void) {
    int a = 1, b = 1;
    int i, next_a;
    for (i = 1; i <= 11; i++) {
        if (i > 1) {
            printf(" ");
        }
        printf("%d/%d", a, b);
        next_a = a + b;
        b = a;
        a = next_a;
    }
    printf("\n");
    return 0;
}