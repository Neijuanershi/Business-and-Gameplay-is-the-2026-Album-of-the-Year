#include <stdio.h>

int main(void)
{
    int x, a, b, c, d, e;

    for (x = 1; x < 10000; x++) {
        if (x % 8 == 1) {
            a = x / 8;
            if (a % 8 == 1) {
                b = a / 8;
                if (b % 8 == 7) {
                    c = b / 8;
                    if (x % 17 == 4) {
                        d = x / 17;
                        if (d % 17 == 15) {
                            e = d / 17;
                            if (e == 2 * c) {
                                printf("%d\n", x);
                                break;
                            }
                        }
                    }
                }
            }
        }
    }

    return 0;
}