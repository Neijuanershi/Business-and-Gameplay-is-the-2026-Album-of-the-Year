#include <stdio.h>

int main(void)
{
    char s1[2005], s2[1005];
    int len1 = 0, len2 = 0;
    int i;
    char ch;

    while ((ch = getchar()) != '\n' && ch != EOF) {
        s1[len1++] = ch;
    }
    s1[len1] = '\0';

    while ((ch = getchar()) != '\n' && ch != EOF) {
        s2[len2++] = ch;
    }
    s2[len2] = '\0';

    if (len1 > 0 && len2 > 0) {
        if (s1[len1 - 1] != ' ' && s2[0] != ' ') {
            s1[len1++] = ' ';
        }
    }

    for (i = 0; i < len2; i++) {
        s1[len1++] = s2[i];
    }
    s1[len1] = '\0';

    printf("%s\n", s1);

    return 0;
}