#include <stdio.h>

char s[1000005];

int main(void)
{
    const char *words[10] = {
        "(Zero)", "(One)", "(Two)", "(Three)", "(Four)",
        "(Five)", "(Six)", "(Seven)", "(Eight)", "(Nine)"
    };
    int cnt[10] = {0};
    int i = 0;
    char prev = '\0';
    if (fgets(s, sizeof(s), stdin) == NULL) {
        printf("\n0 0 0 0 0 0 0 0 0 0\n");
        return 0;
    }
    while (s[i] != '\0' && s[i] != '\n' && s[i] != '\r') {
        char c = s[i];
        if (c >= '0' && c <= '9') {
            int d = c - '0';
            cnt[d]++;
            if (i > 0 && prev >= '0' && prev <= '9') {
                putchar(' ');
            }
            printf("%s", words[d]);
        } else {
            putchar(c);
        }
        prev = c;
        i++;
    }
    putchar('\n');
    for (i = 0; i < 10; i++) {
        if (i > 0) putchar(' ');
        printf("%d", cnt[i]);
    }
    putchar('\n');
    return 0;
}