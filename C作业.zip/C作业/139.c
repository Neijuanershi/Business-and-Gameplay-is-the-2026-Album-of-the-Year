#include <stdio.h>

int main(void)
{
    int i, j;
    for (i = 0; i < 5; i++) {
        for (j = 0; j < 5; j++) {
            if (j > 0) {
                printf(" ");
            }
            if (j < i) {
                printf("0");
            } else {
                printf("%d", j - i + 1);
            }
        }
        printf("\n");
    }
    return 0;
}