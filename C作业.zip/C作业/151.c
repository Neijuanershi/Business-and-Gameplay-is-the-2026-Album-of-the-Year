#include <stdio.h>

int main(void)
{
    long long ans = 0;
    int error = 0;
    char ch;
    int has_char = 0;

    while ((ch = getchar()) != '\n' && ch != EOF) {
        if (ch == ' ' || ch == '\r') {
            continue;
        }
        has_char = 1;
        if (ch >= '0' && ch <= '9') {
            ans = ans * 16 + (ch - '0');
        } else if (ch >= 'A' && ch <= 'F') {
            ans = ans * 16 + (ch - 'A' + 10);
        } else if (ch >= 'a' && ch <= 'f') {
            ans = ans * 16 + (ch - 'a' + 10);
        } else {
            error = 1;
        }
    }

    if (error || !has_char) {
        printf("ERROR\n");
    } else {
        printf("%lld\n", ans);
    }

    return 0;
}