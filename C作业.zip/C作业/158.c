#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(void)
{
    int n;
    int i, j, minIdx;
    int len;
    int ch;
    char **strs;
    char *tmp;
    char buf[1000005];
    if (scanf("%d", &n) != 1) return 0;
    while ((ch = getchar()) != '\n' && ch != EOF) ;
    if (n <= 0) return 0;
    strs = (char **)malloc(sizeof(char *) * n);
    if (strs == NULL) return 0;
    for (i = 0; i < n; i++) {
        if (fgets(buf, sizeof(buf), stdin) == NULL) buf[0] = '\0';
        len = strlen(buf);
        while (len > 0 && (buf[len - 1] == '\n' || buf[len - 1] == '\r')) buf[--len] = '\0';
        strs[i] = (char *)malloc(len + 1);
        if (strs[i] != NULL) strcpy(strs[i], buf);
    }
    for (i = 0; i < n - 1; i++) {
        minIdx = i;
        for (j = i + 1; j < n; j++) {
            if (strcmp(strs[j], strs[minIdx]) < 0) minIdx = j;
        }
        if (minIdx != i) {
            tmp = strs[i];
            strs[i] = strs[minIdx];
            strs[minIdx] = tmp;
        }
    }
    for (i = 0; i < n; i++) {
        if (strs[i] != NULL) printf("%s\n", strs[i]);
    }
    for (i = 0; i < n; i++) free(strs[i]);
    free(strs);
    return 0;
}