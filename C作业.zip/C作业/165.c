#include <stdio.h>

char s[1000005];

int main(void)
{
    int len = 0;
    int i;
    int maxIdx = 0;
    if (fgets(s, sizeof(s), stdin) == NULL) {
        printf("\n");
        return 0;
    }
    while (s[len] != '\0' && s[len] != '\n' && s[len] != '\r') len++;
    for (i = 1; i < len; i++) {
        if (s[i] > s[maxIdx]) maxIdx = i;
    }
    if (len > 0) {
        putchar(s[maxIdx]);
        for (i = 0; i < len; i++) {
            if (i != maxIdx) putchar(s[i]);
        }
    }
    putchar('\n');
    return 0;
}