#include <stdio.h>

int main(void)
{
    int a[3][4];
    int i, j;

    for (i = 0; i < 3; i++) {
        for (j = 0; j < 4; j++) {
            scanf("%d", &a[i][j]);
        }
    }

    for (i = 0; i < 3; i++) {
        printf("%d", a[i][3]);
        for (j = 0; j < 3; j++) {
            printf(" %d", a[i][j]);
        }
        printf("\n");
    }

    return 0;
}