#include <stdio.h>

int main(void)
{
    int n, m, i, j, x, min;
    scanf("%d %d", &n, &m);

    for (i = 0; i < n; i++) {
        scanf("%d", &min);
        for (j = 1; j < m; j++) {
            scanf("%d", &x);
            if (x < min) {
                min = x;
            }
        }
        if (i > 0) {
            printf(" ");
        }
        printf("%d", min);
    }
    printf("\n");

    return 0;
}