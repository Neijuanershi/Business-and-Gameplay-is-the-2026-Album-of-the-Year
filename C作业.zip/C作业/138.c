#include <stdio.h>

int main(void)
{
    int n, m, i, j, x;
    int max_val, max_r = 0, max_c = 0;
    int first = 1;

    scanf("%d %d", &n, &m);

    for (i = 0; i < n; i++) {
        for (j = 0; j < m; j++) {
            scanf("%d", &x);
            if (first) {
                max_val = x;
                max_r = i;
                max_c = j;
                first = 0;
            } else if (x > max_val) {
                max_val = x;
                max_r = i;
                max_c = j;
            }
        }
    }

    printf("%d %d %d\n", max_val, max_r, max_c);

    return 0;
}