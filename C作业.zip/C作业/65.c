#include <stdio.h>

int main(void) {
    int count = 0;
    char c;
    for (c = 'a'; c <= 'z'; c++) {
        printf("%c", c);
        count++;
        if (count % 13 == 0) {
            printf("\n");
        }
    }
    for (c = 'z'; c >= 'a'; c--) {
        printf("%c", c);
        count++;
        if (count % 13 == 0) {
            printf("\n");
        }
    }
    return 0;
}