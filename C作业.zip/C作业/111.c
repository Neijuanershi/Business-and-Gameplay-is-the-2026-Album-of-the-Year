#include <stdio.h>

int main(void)
{
    int a[10];
    int i, max_idx, temp;

    for (i = 0; i < 10; i++) {
        scanf("%d", &a[i]);
    }

    max_idx = 0;
    for (i = 1; i < 10; i++) {
        if (a[i] > a[max_idx]) {
            max_idx = i;
        }
    }

    temp = a[0];
    a[0] = a[max_idx];
    a[max_idx] = temp;

    for (i = 0; i < 10; i++) {
        if (i > 0) {
            printf(" ");
        }
        printf("%d", a[i]);
    }
    printf("\n");

    return 0;
}