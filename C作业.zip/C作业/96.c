#include <stdio.h>

int main(void)
{
    int n = 12;
    int m = 7;
    int i;
    int ans = 0;

    for (i = 2; i <= n; i++) {
        ans = (ans + m) % i;
    }

    printf("%d\n", ans + 1);

    return 0;
}