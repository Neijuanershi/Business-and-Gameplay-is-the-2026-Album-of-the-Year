#include <stdio.h>

int main(void)
{
    int a[10];
    int i;

    for (i = 0; i < 10; i++) {
        scanf("%d", &a[i]);
    }

    for (i = 0; i < 10; i++) {
        printf("%d", a[i]);
        if ((i + 1) % 4 == 0 || i == 9) {
            printf("\n");
        } else {
            printf(" ");
        }
    }

    return 0;
}