#include <stdio.h>

int main(void)
{
    int n, i, j, num = 1;
    scanf("%d", &n);
    int a[n][n];
    int top = 0, bottom = n - 1, left = 0, right = n - 1;

    while (num <= n * n) {
        for (i = left; i <= right; i++) {
            a[top][i] = num++;
        }
        top++;
        for (i = top; i <= bottom; i++) {
            a[i][right] = num++;
        }
        right--;
        for (i = right; i >= left; i--) {
            a[bottom][i] = num++;
        }
        bottom--;
        for (i = bottom; i >= top; i--) {
            a[i][left] = num++;
        }
        left++;
    }

    for (i = 0; i < n; i++) {
        for (j = 0; j < n; j++) {
            if (j > 0) {
                printf(" ");
            }
            printf("%d", a[i][j]);
        }
        printf("\n");
    }

    return 0;
}