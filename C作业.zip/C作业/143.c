#include <stdio.h>

int main(void)
{
    int n, i, j, temp;
    int a[105], b[105];
    
    scanf("%d", &n);
    for (i = 0; i < n; i++) {
        scanf("%d", &a[i]);
        b[i] = a[i];
    }
    
    for (i = 0; i < n - 1; i++) {
        for (j = 0; j < n - 1 - i; j++) {
            if (b[j] > b[j + 1]) {
                temp = b[j];
                b[j] = b[j + 1];
                b[j + 1] = temp;
            }
        }
    }
    
    int m = 0;
    for (i = 0; i < n; i++) {
        if (i == 0 || b[i] != b[i - 1]) {
            b[m++] = b[i];
        }
    }
    
    for (i = 0; i < n; i++) {
        for (j = 0; j < m; j++) {
            if (a[i] == b[j]) {
                if (i > 0) {
                    printf(" ");
                }
                printf("%d", j + 1);
                break;
            }
        }
    }
    printf("\n");
    
    return 0;
}