#include <stdio.h>
#include <string.h>

int main(void)
{
    char s[1005];
    int len, i, flag = 1;

    scanf("%s", s);
    len = strlen(s);

    for (i = 0; i < len / 2; i++) {
        if (s[i] != s[len - 1 - i]) {
            flag = 0;
            break;
        }
    }

    if (flag) {
        printf("Yes\n");
    } else {
        printf("No\n");
    }

    return 0;
}