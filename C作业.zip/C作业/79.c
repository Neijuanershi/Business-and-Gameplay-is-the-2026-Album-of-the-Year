#include <stdio.h>

int main(void)
{
    int i, sq, mod;
    int first = 1;
    for (i = 1; i <= 999; i++) {
        sq = i * i;
        mod = 10;
        while (i >= mod) {
            mod *= 10;
        }
        if (sq % mod == i) {
            if (!first) {
                printf(" ");
            }
            printf("%d", i);
            first = 0;
        }
    }
    printf("\n");
    return 0;
}