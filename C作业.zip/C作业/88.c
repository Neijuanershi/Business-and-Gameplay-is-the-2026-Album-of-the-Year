#include <stdio.h>

int main(void)
{
    int id[10];
    double salary[10];
    double sum = 0.0;
    double avg;
    int i;

    for (i = 0; i < 10; i++) {
        scanf("%d %lf", &id[i], &salary[i]);
        sum += salary[i];
    }

    avg = sum / 10.0;
    printf("%.2f\n", avg);

    for (i = 0; i < 10; i++) {
        if (salary[i] < avg) {
            printf("%d %.2f\n", id[i], salary[i]);
        }
    }

    return 0;
}