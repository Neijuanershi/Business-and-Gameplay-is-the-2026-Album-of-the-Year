#include <stdio.h>

int main(void) {
    int y, m, days;
    scanf("%d-%d", &y, &m);
    if (m == 2) {
        if ((y % 4 == 0 && y % 100 != 0) || (y % 400 == 0)) {
            days = 29;
        } else {
            days = 28;
        }
    } else if (m == 4 || m == 6 || m == 9 || m == 11) {
        days = 30;
    } else {
        days = 31;
    }
    printf("%d\n", days);
    return 0;
}