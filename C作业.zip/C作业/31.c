#include <stdio.h>

int main(void) {
    int y, m, d;
    scanf("%d-%d-%d", &y, &m, &d);
    if (d > 1) {
        d--;
    } else {
        if (m > 1) {
            m--;
            if (m == 2) {
                if ((y % 4 == 0 && y % 100 != 0) || (y % 400 == 0)) {
                    d = 29;
                } else {
                    d = 28;
                }
            } else if (m == 4 || m == 6 || m == 9 || m == 11) {
                d = 30;
            } else {
                d = 31;
            }
        } else {
            y--;
            m = 12;
            d = 31;
        }
    }
    printf("%d-%d-%d\n", y, m, d);
    return 0;
}