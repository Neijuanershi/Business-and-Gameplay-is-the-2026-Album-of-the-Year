#include <stdio.h>

int main(void)
{
    int n, i, j, temp;
    int a[10005];
    double median;

    scanf("%d", &n);
    for (i = 0; i < n; i++) {
        scanf("%d", &a[i]);
    }

    for (i = 0; i < n - 1; i++) {
        for (j = 0; j < n - 1 - i; j++) {
            if (a[j] > a[j + 1]) {
                temp = a[j];
                a[j] = a[j + 1];
                a[j + 1] = temp;
            }
        }
    }

    if (n % 2 != 0) {
        median = a[n / 2];
    } else {
        median = (a[n / 2 - 1] + a[n / 2]) / 2.0;
    }

    printf("%.2f\n", median);

    return 0;
}