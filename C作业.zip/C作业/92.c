#include <stdio.h>

int main(void)
{
    int y, m, d;
    int days[] = {0, 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};
    int total = 0;
    int i;

    scanf("%d-%d-%d", &y, &m, &d);

    if ((y % 4 == 0 && y % 100 != 0) || (y % 400 == 0)) {
        days[2] = 29;
    }

    for (i = 1; i < m; i++) {
        total += days[i];
    }
    total += d;

    printf("%d\n", total);

    return 0;
}