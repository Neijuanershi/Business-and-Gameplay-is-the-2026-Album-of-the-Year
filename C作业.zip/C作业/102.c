#include <stdio.h>

int main(void)
{
    int arr[] = {46, 52, 68, 71, 74, 83, 87, 95};
    int target, left = 0, right = 7, mid;
    int found = 0, pos = -1;

    scanf("%d", &target);

    while (left <= right) {
        mid = left + (right - left) / 2;
        if (arr[mid] == target) {
            found = 1;
            pos = mid + 1;
            break;
        } else if (arr[mid] < target) {
            left = mid + 1;
        } else {
            right = mid - 1;
        }
    }

    if (found) {
        printf("%d\n", pos);
    } else {
        printf("No\n");
    }

    return 0;
}