#include <stdio.h>

int main(void)
{
    int a[5][5];
    int i, j;
    int num = 1;

    for (i = 0; i < 5; i++) {
        for (j = 0; j < 5; j++) {
            a[i][j] = num++;
        }
    }

    for (i = 0; i < 5; i++) {
        for (j = 0; j < 5; j++) {
            if (j > 0) {
                printf(" ");
            }
            printf("%d", a[i][j]);
        }
        printf("\n");
    }

    return 0;
}