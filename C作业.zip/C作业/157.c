
#include <stdio.h>
#include <string.h>

char min[100005];
char buf[100005];

int main(void)
{
    int n;
    int i;
    int len;
    int ch;
    scanf("%d", &n);
    while ((ch = getchar()) != '\n' && ch != EOF) ;
    for (i = 0; i < n; i++) {
        fgets(buf, sizeof(buf), stdin);
        len = strlen(buf);
        while (len > 0 && (buf[len - 1] == '\n' || buf[len - 1] == '\r')) buf[--len] = '\0';
        if (i == 0 || strcmp(buf, min) < 0) strcpy(min, buf);
    }
    printf("%s\n", min);
    return 0;
}