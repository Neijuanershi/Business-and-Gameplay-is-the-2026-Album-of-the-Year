#include <stdio.h>

int main(void)
{
    int n = 1;
    int temp, i;

    while (1) {
        temp = n;
        for (i = 0; i < 5; i++) {
            if (temp % 5 == 1) {
                temp = (temp - 1) / 5 * 4;
            } else {
                break;
            }
        }
        if (i == 5) {
            printf("%d\n", n);
            break;
        }
        n++;
    }

    return 0;
}