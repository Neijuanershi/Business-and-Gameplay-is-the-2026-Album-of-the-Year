#include <stdio.h>

int main(void)
{
    int i;
    int peach = 1534;
    for (i = 1; i <= 9; i++) {
        peach = peach / 2 - 1;
    }
    printf("%d\n", peach);
    return 0;
}