#include <stdio.h>

int main(void)
{
    int a, b, c, d, e, f, g, h, i;
    int det;

    scanf("%d %d %d", &a, &b, &c);
    scanf("%d %d %d", &d, &e, &f);
    scanf("%d %d %d", &g, &h, &i);

    det = a * (e * i - f * h) - b * (d * i - f * g) + c * (d * h - e * g);

    printf("%d\n", det);

    return 0;
}