#include <stdio.h>

int main(void)
{
    int scores[105];
    int n = 0;
    int score, i, j, temp, limit;

    while (scanf("%d", &score) == 1 && score != 0) {
        scores[n++] = score;
    }

    for (i = 0; i < n - 1; i++) {
        for (j = 0; j < n - 1 - i; j++) {
            if (scores[j] < scores[j + 1]) {
                temp = scores[j];
                scores[j] = scores[j + 1];
                scores[j + 1] = temp;
            }
        }
    }

    limit = n < 10 ? n : 10;
    for (i = 0; i < limit; i++) {
        if (i > 0) {
            printf(" ");
        }
        printf("%d", scores[i]);
    }
    printf("\n");

    return 0;
}