#include <stdio.h>

int main(void)
{
    int a[9];
    int i, num;

    for (i = 0; i < 8; i++) {
        scanf("%d", &a[i]);
    }
    scanf("%d", &num);

    for (i = 7; i >= 0; i--) {
        if (a[i] > num) {
            a[i + 1] = a[i];
        } else {
            break;
        }
    }
    a[i + 1] = num;

    for (i = 0; i < 9; i++) {
        if (i > 0) {
            printf(" ");
        }
        printf("%d", a[i]);
    }
    printf("\n");

    return 0;
}