#include <stdio.h>

int main(void)
{
    int i;
    int peach = 1;
    for (i = 9; i >= 1; i--) {
        peach = (peach + 1) * 2;
    }
    printf("%d\n", peach);
    return 0;
}