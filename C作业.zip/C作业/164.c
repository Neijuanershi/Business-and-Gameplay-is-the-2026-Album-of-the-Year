#include <stdio.h>

char s[1000005];
char letters[1000005];
char digits[1000005];

int main(void)
{
    int i = 0;
    int j = 0;
    int k = 0;
    if (fgets(s, sizeof(s), stdin) == NULL) {
        printf("\n");
        return 0;
    }
    while (s[i] != '\0' && s[i] != '\n' && s[i] != '\r') {
        if (s[i] >= '0' && s[i] <= '9') {
            digits[k++] = s[i];
        } else {
            letters[j++] = s[i];
        }
        i++;
    }
    letters[j] = '\0';
    digits[k] = '\0';
    printf("%s%s\n", letters, digits);
    return 0;
}