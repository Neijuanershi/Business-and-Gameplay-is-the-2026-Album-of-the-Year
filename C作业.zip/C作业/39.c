#include <stdio.h>

int main(void) {
    double e = 1.0;
    double item = 1.0;
    int n = 1;
    while (1) {
        item = item / n;
        if (item < 1e-6) {
            break;
        }
        e = e + item;
        n++;
    }
    printf("%.5f\n", e);
    return 0;
}