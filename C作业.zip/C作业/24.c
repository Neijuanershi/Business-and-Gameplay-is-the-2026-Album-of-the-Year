#include <stdio.h>

int main(void) {
    int x, y;
    scanf("%d", &x);
    if (x == 100) {
        y = 5;
    } else if (x >= 90) {
        y = 4;
    } else if (x >= 80) {
        y = 3;
    } else if (x >= 70) {
        y = 2;
    } else if (x >= 60) {
        y = 1;
    } else {
        y = 0;
    }
    printf("%d\n", y);
    return 0;
}