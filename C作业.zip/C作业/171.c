#include <stdio.h>

char s[1000005];

int main(void)
{
    int i = 0;
    int inWord = 0;
    if (fgets(s, sizeof(s), stdin) == NULL) {
        printf("\n");
        return 0;
    }
    while (s[i] != '\0' && s[i] != '\n' && s[i] != '\r') {
        if (s[i] == ' ' || s[i] == '\t') {
            inWord = 0;
        } else {
            if (!inWord) {
                if (s[i] >= 'a' && s[i] <= 'z') {
                    s[i] = s[i] - 'a' + 'A';
                }
                inWord = 1;
            }
        }
        i++;
    }
    s[i] = '\0';
    printf("%s\n", s);
    return 0;
}