#include <stdio.h>

int main(void) {
    int a, b, c, odd = 0;
    scanf("%d %d %d", &a, &b, &c);
    if (a % 2 != 0) {
        odd++;
    }
    if (b % 2 != 0) {
        odd++;
    }
    if (c % 2 != 0) {
        odd++;
    }
    if (odd == 2) {
        printf("Yes\n");
    } else {
        printf("No\n");
    }
    return 0;
}