#include <stdio.h>

int main(void)
{
    int n, i, j;
    scanf("%d", &n);
    int a[n][n];

    for (i = 0; i < n; i++) {
        for (j = 0; j < n; j++) {
            scanf("%d", &a[i][j]);
        }
    }

    int is_symmetric = 1;
    for (i = 0; i < n; i++) {
        for (j = 0; j < i; j++) {
            if (a[i][j] != a[j][i]) {
                is_symmetric = 0;
                break;
            }
        }
        if (!is_symmetric) {
            break;
        }
    }

    if (is_symmetric) {
        printf("Yes\n");
    } else {
        printf("No\n");
    }

    return 0;
}