#include <stdio.h>

int main(void)
{
    int a[10];
    int m, i;

    for (i = 0; i < 10; i++) {
        scanf("%d", &a[i]);
    }
    scanf("%d", &m);
    m = (m % 10 + 10) % 10;

    for (i = 0; i < 10; i++) {
        if (i > 0) {
            printf(" ");
        }
        printf("%d", a[(i - m + 10) % 10]);
    }
    printf("\n");

    return 0;
}