#include <stdio.h>

int main(void) {
    int i;
    int first = 1;
    for (i = 10; i * i <= 200; i++) {
        if (!first) {
            printf(" ");
        }
        printf("%d", i * i);
        first = 0;
    }
    printf("\n");
    return 0;
}