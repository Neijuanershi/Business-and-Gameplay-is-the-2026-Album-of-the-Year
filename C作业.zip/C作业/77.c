#include <stdio.h>

int main(void)
{
    int n, i;
    scanf("%d", &n);
    printf("%d=", n);
    for (i = 2; i <= n; i++) {
        while (n % i == 0) {
            printf("%d", i);
            n = n / i;
            if (n > 1) {
                printf("*");
            }
        }
    }
    printf("\n");
    return 0;
}