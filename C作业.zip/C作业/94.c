#include <stdio.h>

int main(void)
{
    int counts[11] = {0};
    int h, level;
    int i;

    for (i = 0; i < 20; i++) {
        scanf("%d", &h);
        if (h < 150) {
            level = 1;
        } else {
            level = h / 5 - 28;
            if (level > 10) {
                level = 10;
            }
        }
        counts[level]++;
    }

    for (i = 1; i <= 10; i++) {
        printf("%d %d\n", i, counts[i]);
    }

    return 0;
}