#include <stdio.h>

int main(void)
{
    int counts[10] = {0};
    int count = 0;
    char ch;
    int i;

    while (count < 20) {
        ch = getchar();
        if (ch >= '0' && ch <= '9') {
            counts[ch - '0']++;
            count++;
        }
    }

    for (i = 0; i < 10; i++) {
        printf("%d %d\n", i, counts[i]);
    }

    return 0;
}