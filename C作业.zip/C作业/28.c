#include <stdio.h>

int main(void) {
    double salary, taxable, tax;
    scanf("%lf", &salary);
    taxable = salary - 3500;
    if (taxable <= 0) {
        tax = 0;
    } else if (taxable <= 1500) {
        tax = taxable * 0.03;
    } else if (taxable <= 4500) {
        tax = taxable * 0.10 - 105;
    } else if (taxable <= 9000) {
        tax = taxable * 0.20 - 555;
    } else if (taxable <= 35000) {
        tax = taxable * 0.25 - 1005;
    } else {
        tax = 0;
    }
    printf("%.2f\n", tax);
    return 0;
}