#include <stdio.h>

int main(void) {
    char c, prev, next;
    scanf("%c", &c);
    if (c == 'a') {
        prev = 'z';
    } else {
        prev = c - 1;
    }
    if (c == 'z') {
        next = 'a';
    } else {
        next = c + 1;
    }
    printf("%c %c\n", prev, next);
    return 0;
}