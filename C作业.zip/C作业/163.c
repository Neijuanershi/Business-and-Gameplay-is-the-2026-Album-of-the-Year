#include <stdio.h>

char s[1000005];

int main(void)
{
    int len = 0;
    int i;
    char t;
    if (fgets(s, sizeof(s), stdin) == NULL) {
        printf("\n");
        return 0;
    }
    while (s[len] != '\0') len++;
    while (len > 0 && (s[len - 1] == '\n' || s[len - 1] == '\r')) len--;
    for (i = 0; i < len / 2; i++) {
        t = s[i];
        s[i] = s[len - 1 - i];
        s[len - 1 - i] = t;
    }
    s[len] = '\0';
    printf("%s\n", s);
    return 0;
}