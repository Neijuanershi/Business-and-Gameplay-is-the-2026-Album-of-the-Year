#include <stdio.h>

int main(void) {
    double x, y;
    scanf("%lf", &x);
    if (x <= 100) {
        y = x * 0.9;
    } else {
        y = 100 * 0.9 + (x - 100) * 0.8;
    }
    printf("%.2f\n", y);
    return 0;
}