#include <stdio.h>

int main(void)
{
    double height = 100.0;
    double distance = 100.0;
    int i;

    for (i = 1; i < 10; i++) {
        height = height / 2.0;
        distance = distance + 2.0 * height;
    }
    height = height / 2.0;

    printf("%.2f %.2f\n", distance, height);

    return 0;
}