#include <stdio.h>

char s1[1000005];
char s2[1000005];

int main(void)
{
    int len1 = 0, len2 = 0;
    int i = 0;
    int j;
    int count = 0;
    if (fgets(s1, sizeof(s1), stdin) == NULL) {
        printf("0\n");
        return 0;
    }
    if (fgets(s2, sizeof(s2), stdin) == NULL) {
        printf("0\n");
        return 0;
    }
    while (s1[len1] != '\0' && s1[len1] != '\n' && s1[len1] != '\r') len1++;
    while (s2[len2] != '\0' && s2[len2] != '\n' && s2[len2] != '\r') len2++;
    if (len2 == 0) {
        printf("0\n");
        return 0;
    }
    while (i + len2 <= len1) {
        for (j = 0; j < len2; j++) {
            if (s1[i + j] != s2[j]) break;
        }
        if (j == len2) {
            count++;
            i += len2;
        } else {
            i++;
        }
    }
    printf("%d\n", count);
    return 0;
}