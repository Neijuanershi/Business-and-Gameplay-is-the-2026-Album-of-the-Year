#include <stdio.h>

int main(void) {
    double principal, interest;
    int years;
    scanf("%lf %d", &principal, &years);
    if (years == 1) {
        interest = principal * 1 * 0.035;
    } else if (years == 2) {
        interest = principal * 2 * 0.044;
    } else if (years == 3) {
        interest = principal * 3 * 0.05;
    } else if (years == 5) {
        interest = principal * 5 * 0.065;
    } else {
        printf("ERROR\n");
        return 0;
    }
    printf("%.2f\n", interest);
    return 0;
}