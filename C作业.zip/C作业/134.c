#include <stdio.h>

int main(void)
{
    int n, i, j, x;
    long long sum = 0;

    scanf("%d", &n);

    for (i = 0; i < n; i++) {
        for (j = 0; j < n; j++) {
            scanf("%d", &x);
            if (i == 0 || i == n - 1 || j == 0 || j == n - 1) {
                sum += x;
            }
        }
    }

    printf("%lld\n", sum);

    return 0;
}